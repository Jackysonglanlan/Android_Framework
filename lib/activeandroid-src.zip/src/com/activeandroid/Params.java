package com.activeandroid;

class Params {
	public static final String VERSION = "3.0.0";
	public static final boolean IS_TRIAL = false;
}